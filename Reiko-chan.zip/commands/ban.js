exports.run = async(client, message, args) => {
    
       if  (!message.member.hasPermissions(["BAN_MEMBERS"])) return message.reply("You don't have the appropriate rights to run this command!");
       let reason = args.slice(1).join(' ');
       let user = message.mentions.users.first();
       if (reason.length < 1) return message.reply('You must specify a reason for the ban!');
       if (message.mentions.users.size < 1) return message.reply('You must select the user you want to ban!').catch(console.error);
    
       if (!message.guild.member(user).bannable) return message.reply("I can't ban this user!");
       let member = await message.guild.member(user).ban(0)
    
       const Discord = require("discord.js");
       const embed = new Discord.RichEmbed()
           .setColor('#FF0000')
           .setTimestamp()
           .addField('Action:', '__***BAN***__')
           .addField('User:', `${user.username} `)
           .addField('Staff:', `${message.author.username}`)
           .addField('Reason', reason)
           .setFooter('A Official DynatriSoft bot')
       return message.channel.sendEmbed(embed).catch(console.error);
      
   };