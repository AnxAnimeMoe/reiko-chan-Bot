exports.run = async(client, message, args) => {
    
        if  (!message.member.hasPermissions(["KICK_MEMBERS"])) return message.reply("You don't have the appropriate rights to run this command!");
        let reason = args.slice(1).join(' ');
        let user = message.mentions.users.first(); 
        if (reason.length < 1) return message.reply('You must specify a reason for the kick!');
        if (message.mentions.users.size < 1) return message.reply('You must select the user you want to kick!').catch(console.error);
    
        if (!message.guild.member(user).kickable) return message.reply("I can't kick this user!");
        let member = await message.guild.member(user).kick()
     
        const Discord = require("discord.js");
        const embed = new Discord.RichEmbed()
            .setColor('#FF0000')
            .setTimestamp()
            .addField('Action:', '__***Kick***__')
            .addField('User:', `${user.username}`)
            .addField('Staff:', `${message.author.username}`)
            .addField('Reason', reason)
            .setFooter('The Official AnxAnime,moe bot')
        return message.channel.sendEmbed(embed).catch(console.error);
        
    };